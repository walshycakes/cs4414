Submitted by: Bryan Walsh (bpw7xx), Jared Culp (jjc4fb)
Lab 1--Linked List

-Compile using "make"

-Run executable "lab1"
